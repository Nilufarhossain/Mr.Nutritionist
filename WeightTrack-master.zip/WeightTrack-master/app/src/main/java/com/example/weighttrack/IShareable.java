package com.example.weighttrack;

public interface IShareable {

    public void Share();
}
