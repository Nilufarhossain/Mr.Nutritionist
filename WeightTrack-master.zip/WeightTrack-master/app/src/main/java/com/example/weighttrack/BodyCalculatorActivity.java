package com.example.weighttrack;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;

import java.util.Locale;

public class BodyCalculatorActivity extends AppCompatActivity implements IShareable{

    private DrawerLayout mDrawerLayout;
    private Spinner activityLevelSpinner;
    private TextView tvDailyIntake;
    private TextView tvDays;
    private EditText etDeficit;
    private EditText etGoal;
    private double weight;
    private double goal;
    private int deficit;
    private int result;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_body_calculator);
        weight = 0;
        goal = 0;
        deficit = 0;
        result = 0;
        InitUI();
    }

    @Override
    public void onResume(){
        super.onResume();
        InitUI();
        InitSpinner();
    }

    public void InitUI(){
        NavigationSetUp();
        CreateToolbar();
        SetViews();
    }

    public void NavigationSetUp(){
        mDrawerLayout = findViewById(R.id.drawer_layout);
        final NavigationView navigationView = findViewById(R.id.nav_view);

        //Access the header layout
        View headerView = navigationView.getHeaderView(0);
        TextView headerName = headerView.findViewById(R.id.tvHeaderName);
        if (PreferenceManager.get_name().equals("")){headerName.setText(R.string.nav_header_error);}
        else {
            String text = this.getText(R.string.nav_welcome).toString();
            headerName.setText(String.format(Locale.ENGLISH, text, PreferenceManager.get_name()));
        }

        navigationView.setNavigationItemSelectedListener(
                new NavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(MenuItem menuItem) {
                        // set item as selected to persist highlight
                        menuItem.setChecked(true);
                        // close drawer when item is tapped
                        mDrawerLayout.closeDrawers();

                        // Add code here to update the UI based on the item selected
                        // For example, swap UI fragments here

                        switch (menuItem.getItemId()){
                            case R.id.nav_home:
                                Intent home = new Intent(getBaseContext(),HomeActivity.class);
                                startActivity(home);
                                break;
                            case R.id.nav_converter:
                                Intent body = new Intent(getBaseContext(),BodyCalculatorActivity.class);
                                startActivity(body);
                                break;
                            case R.id.nav_bmi_calc:
                                Intent bmi = new Intent(getBaseContext(),BMIActivity.class);
                                startActivity(bmi);
                                break;
                            case R.id.nav_history:
                                Intent history = new Intent(getBaseContext(),HistoryActivity.class);
                                startActivity(history);
                                break;
                            case R.id.nav_about:
                                Intent about = new Intent(getBaseContext(),AboutActivity.class);
                                startActivity(about);
                                break;
                        }
                        return false;
                    }
                });
    }

    public void CreateToolbar() {
        Toolbar toolbar = findViewById(R.id.mainToolbar);
        setSupportActionBar(toolbar);
        ActionBar actionbar = getSupportActionBar();
        actionbar.setDisplayHomeAsUpEnabled(true);
        actionbar.setHomeAsUpIndicator(R.drawable.ic_menu_white);
        actionbar.setTitle(getText(R.string.calculator));
    }

    public void SetViews(){
        activityLevelSpinner = findViewById(R.id.activityLevelSpinner);
        tvDailyIntake = findViewById(R.id.tvMaintenenceCalories);
        etGoal = findViewById(R.id.etGoalWeight);
        etDeficit = findViewById(R.id.etDeficit);
        tvDays = findViewById(R.id.tvDaysToReachGoal);
    }

    public void InitSpinner(){
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,R.array.activity_levels,R.layout.support_simple_spinner_dropdown_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        activityLevelSpinner.setAdapter(adapter);

        activityLevelSpinner.setOnItemSelectedListener(
                new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        SetDailyIntake(position);
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                }
        );
    }

    public void SetDailyIntake(int spinnerPosition){
        String calories;
        Weight lastWeight = HomeActivity.get_recent_weight();

        if (lastWeight == null){
            tvDailyIntake.setText(getText(R.string.stats_error));
            return;
        }

        weight = lastWeight.get_weight();
        int height = PreferenceManager.get_height();
        int age = PreferenceManager.get_age();
        String gender = PreferenceManager.get_gender();

        calories = String.valueOf(Calc.MaintenanceCalories(weight, height, age, gender, spinnerPosition));
        String calorieText = getText(R.string.maintenence_calories).toString();
        tvDailyIntake.setText(String.format(Locale.US, calorieText, calories));
    }

    public void CalculateDays(View v){
        String strGoal = etGoal.getText().toString();
        String strDeficit = etDeficit.getText().toString();

        if (strGoal.equals("") || strDeficit.equals("")){
            Toast.makeText(this,R.string.body_calc_null, Toast.LENGTH_LONG).show();
            return;
        }

        goal = Double.parseDouble(etGoal.getText().toString());
        deficit = Integer.parseInt(etDeficit.getText().toString());
        result = Calc.DaysToReachGoalWeight(deficit,weight,goal);
        tvDays.setText(String.format(Locale.US,getText(R.string.days_result).toString(),result));
    }

    public void Share(){
        String strResult = String.format(Locale.US, getText(R.string.share_body).toString(),result,goal,PreferenceManager.get_weightUnit(),deficit);
        Intent sendIntent = new Intent();
        sendIntent.setAction(Intent.ACTION_SEND);
        sendIntent.putExtra(Intent.EXTRA_TEXT, strResult);
        sendIntent.setType("text/plain");
        startActivity(Intent.createChooser(sendIntent, getResources().getText(R.string.share_title)));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        if(this instanceof IShareable) {
            inflater.inflate(R.menu.action_bar, menu);
        } else {
            inflater.inflate(R.menu.action_bar_no_share, menu);
        }
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_settings:
                Intent i = new Intent(this, SettingsActivity.class);
                startActivity(i);
                return true;

            case R.id.action_share:
                Share();
                return true;

            case android.R.id.home:
                mDrawerLayout.openDrawer(GravityCompat.START);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
